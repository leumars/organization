
<p align="center" id="mainHead">Admin Main Page</p>
<p align="center" style="font-family:Verdana, Arial, Helvetica, sans-serif;font-size:14px; margin-bottom:40px;">Choose a menu from the left navigation to get started</p>


<div class="catBox">
<img src="../images/korganizer.png" class="cImage" />
<a href="<?php echo WEB_ROOT; ?>admin/account">Account Information</a>
<p>Get the account details of any customer, credit, debit funds from it or activate, de-activate fund transfers.</p>
</div>

<div class="catBox">
<img src="../images/users.png" class="cImage" />
<a href="<?php echo WEB_ROOT; ?>admin/user">Users Details</a>
<p>View all of your customer details, Activate or Inactive them for login to the system, or delete them.</p>
</div>
